function drawImage(url, x, y) {
    var image = new Image();
    image.onload = function() {
        ctx.drawImage(image,0,0,860,821,x,y,50,50);
    }
    image.src = url;
}

class picture {
  constructor(image, x, y) {
    this.image = image;
    this.x = x;
    this.y = y;
  }
  border(){
    if (this.x > 500) {
        this.x = 0
    } else if (this.x < 0) {
        this.x = 500
    }
    if (this.y > 500) {
        this.y = 0
    } else if (this.y < 0) {
        this.y = 500
    }
  }
  move() {
      this.y += Math.floor(Math.random()*10 - Math.random()*10)
      this.x += Math.floor(Math.random()*10 - Math.random()*10)
  }
}


const canvas = document.querySelector('#canvas');
var c = document.getElementById("canvas");
var ctx = c.getContext("2d");
var xx = 0;
var yy = 0;
var sprite = "https://th.bing.com/th/id/R.376c0ead017eca41b5e9796ebc2b04b8?rik=i060pi0yOKdMwA&pid=ImgRaw&r=0"
Key = { 
    _pressed:{},
    LEFT:37,
    UP:38,
    RIGHT:39,
    DOWN:40,

    isDown:function(keyCode) {
        return this._pressed[keyCode];
    },

    onKeydown:function(event) {
        this._pressed[event.keyCode] = true;
    },

    onKeyup:function(event) {
        delete this._pressed[event.keyCode];
    }
};


window.addEventListener('keyup', function(event) { Key.onKeyup(event); }, false);
window.addEventListener('keydown', function(event) { Key.onKeydown(event); }, false);
 
function left() {
    xx -= 5;
};

function right() {
    xx += 5;
};

function up() {
    yy -= 5;
};

function down() {
    yy += 5;
};

function Input(){
    
    if (Key.isDown(Key.UP)) {
        up()
    };
    if (Key.isDown(Key.LEFT)) {
        left()
    };
    if (Key.isDown(Key.DOWN)) {
        down()
    };
    if (Key.isDown(Key.RIGHT)) {
        right()
    };
};
life = [];
for (let asdasd = 0; asdasd < 100; asdasd++) {
    life.push(new picture(sprite, Math.floor(Math.random()*500), Math.floor(Math.random()*500)));
}
console.log(life);
function update(progress) {
    Input()
}

function clear(ctx) {
    ctx.globalCompositeOperation = 'copy';
}

// It literally only shows ONE ONLY ONE
function draw() { 
    for (let i = 0; i < life.length; i++) {
        life[i].move();
        life[i].border();
        drawImage(life[i].image, life[i].x, life[i].y);
    }
}

function loop() {
    update();
    clear(ctx);
    draw();
}
function animate() {
    loop();
    requestAnimationFrame(animate);
}
setInterval(animate(), 1000)