
var comp_list = [
   'source-over',
   'source-in',
   'source-out',
   'source-atop',
   'destination-over',
   'destination-in',
   'destination-out',
   'destination-atop',
   'lighter',
   'xor',
   'multiply',
   'screen',
   'overlay',
    'darken',
    'lighten',
    'color-dodge',
    'color-burn',
    'hard-light',
    'soft-light',
    'difference',
    'exclusion',
    'hue',
    'saturation',
    'color',
    'luminosity'
];


function drawImage(url, x, y) {
    var image = new Image();
    image.onload = function() {
        ctx.drawImage(image,0,0,860,821,x,y,50,50);
    }
    image.src = url;
}


const canvas = document.querySelector('#canvas');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
var c = document.getElementById("canvas");
var ctx = c.getContext("2d");
var xx = 0;
var yy = 0;
var sprite = "https://th.bing.com/th/id/R.7064401790ca51e2db2c1fa0022ba7d7?rik=t5X6yBD%2fwT128A&riu=http%3a%2f%2fwww.pngmart.com%2ffiles%2f12%2fDisney-XD-Logo-Transparent-PNG.png&ehk=wMU6LOAeKbi8gb38Ypr5PrEnWh84ycAlfeYj3B4plHk%3d&risl=&pid=ImgRaw&r=0"
Key = { 
    _pressed:{},
    LEFT:37,
    UP:38,
    RIGHT:39,
    DOWN:40,

    isDown:function(keyCode) {
        return this._pressed[keyCode];
    },

    onKeydown:function(event) {
        this._pressed[event.keyCode] = true;
    },

    onKeyup:function(event) {
        delete this._pressed[event.keyCode];
    }
};


window.addEventListener('keyup', function(event) { Key.onKeyup(event); }, false);
window.addEventListener('keydown', function(event) { Key.onKeydown(event); }, false);
 
function left() {
    xx -= 5;
};

function right() {
    xx += 5;
};

function up() {
    yy -= 5;
};

function down() {
    yy += 5;
};

function Input(){
    Key = Key
    if (Key.isDown(Key.UP)) {
        up()
    };
    if (Key.isDown(Key.LEFT)) {
        left()
    };
    if (Key.isDown(Key.DOWN)) {
        down()
    };
    if (Key.isDown(Key.RIGHT)) {
        right()
        console.log("RIGHT");
    };
};

function surround(spritee, xxx, yyy) {
    for (let y = -10; y < 10; y++) {
        for (let x = -10; x < 10; x++) {
            drawImage(sprite, ((x*50)+xxx), ((y*50)+yyy));
        }
    }
}

let start, previousTimeStamp;

function step(timestamp) {
    Input();
    if (start === undefined) {
        start = timestamp;
    }

    if (previousTimeStamp != timestamp) {
        ctx.clearRect(0,0,canvas.width,canvas.height);
        ctx.beginPath();
        surround(sprite, xx, yy)
        ctx.closePath();
        
    }

    previousTimeStamp = timestamp
    window.requestAnimationFrame(step);
    console.log(timestamp);
}

window.requestAnimationFrame(step)

