var Game = function () {

    var canvas = document.getElementById("canvas");

    var screen = canvas.getContext('2d');
    this.screen = screen;

    var gameSize = { x: canvas.width, y: canvas.height };

    this.size = gameSize;

    this.accesories = [];

    this.player = new Player(this, gameSize);

    this.bodies = [];

    this.bodies = this.bodies.concat(this.player);

    this.map = { x: 7, y: 7 };

    //this.movementMap = getCurrentMap(this.map.x, this.map.y);

    this.isPaused = false;

    var self = this;


    var buttonPressed = function (b) {
        if (typeof(b) == "object") {
            return b.pressed;
        }
        return b == 1.0;
    };
    var tick = function () {

        // Update game state.
        self.update();

        // Draw game bodies.
        self.draw(screen, gameSize);

        // Queue up the next call to tick with the browser.
        requestAnimationFrame(tick);
    };

    // Run the first game tick.  All future calls will be scheduled by
    // the tick() function itself.
    tick();

    Sound.overworld.play();
};

Game.prototype = {

    // **update()** runs the main game logic.
    update: function () {
        var self = this;
        var link = self.player;

        if (this.pauseTransitionTime) {
            this.pauseTransitionTime -= 2;
            return;
        }

        if (this.unpauseTransitionTime) {
            this.unpauseTransitionTime -= 2;
        }

        if (this.isPaused) {
            this.itemCursor.update();

            if (this.player.keyboarder.isDown(this.player.keyboarder.KEYS.ENTER) || TOUCH.START) {
                this.unpause();
            } else if (this.player.keyboarder.isDown(this.player.keyboarder.KEYS.LEFT) || TOUCH.LEFT) {
                this.itemCursor.moveLeft();
            } else if (this.player.keyboarder.isDown(this.player.keyboarder.KEYS.RIGHT) || TOUCH.RIGHT) {
                this.itemCursor.moveRight();
            }

            return;
        }

        if (this.addRupeeCount) {
            Sound.rupees.play();

            if (this.player.rupees < 255) {
                this.player.rupees++;
            }
            this.addRupeeCount--;

            if (this.addRupeeCount === 0) {
                Sound.rupees.stop();
            }
        }

        if (this.subtractRupeeCount) {
            Sound.rupees.play();

            if (this.player.rupees > 0) {
                this.player.rupees--;
            }
            this.subtractRupeeCount--;

            if (this.subtractRupeeCount === 0) {
                Sound.rupees.stop();
            }
        }

        if (this.screenTransitionTime) {
            if (this.screenTransitionDir === "up") {
                var origMapTop = parseInt(this.viewport.css("background-position-y"));

                if (origMapTop < 0) {
                    var newMapTop = origMapTop + 4;
                    this.viewport.css("background-position-y", newMapTop + "px");

                    this.player.center.y += 4;
                }

                this.screenTransitionTime -= 4;

                //shuffle link's feet during screen transition
                this.player.id = this.screenTransitionTime % 64 < 32 ? "link-up-1" : "link-up-2";

                if (this.screenTransitionTime === 0) {
                    this.player.center.y -= 9;
                }
            } else if (this.screenTransitionDir === "down") {
                var origMapTop = parseInt(this.viewport.css("background-position-y"));

                if (origMapTop > -1232) {
                    var newMapTop = origMapTop - 4;
                    this.viewport.css("background-position-y", newMapTop + "px");

                    this.player.center.y -= 4;
                }

                this.screenTransitionTime -= 4;

                this.player.id = this.screenTransitionTime % 64 < 32 ? "link-down-1" : "link-down-2";

                if (this.screenTransitionTime === 0) {
                    this.player.center.y += 8;
                }
            } else if (this.screenTransitionDir === "left") {
                var origMapLeft = parseInt(this.viewport.css("background-position-x"));

                if (origMapLeft < 0) {
                    var newMapLeft = origMapLeft + 4;
                    this.viewport.css("background-position-x", newMapLeft + "px");

                    this.player.center.x += 4;
                }

                this.screenTransitionTime -= 4;

                this.player.id = this.screenTransitionTime % 64 < 32 ? "link-left-1" : "link-left-2";

                if (this.screenTransitionTime === 0) {
                    this.player.center.x -= 8;
                }
            } else if (this.screenTransitionDir === "right") {
                var origMapLeft = parseInt(this.viewport.css("background-position-x"));

                if (origMapLeft > -3840) {
                    var newMapLeft = origMapLeft - 4;
                    this.viewport.css("background-position-x", newMapLeft + "px");

                    this.player.center.x -= 4;
                }

                this.screenTransitionTime -= 4;

                this.player.id = this.screenTransitionTime % 64 < 32 ? "link-right-1" : "link-right-2";

                if (this.screenTransitionTime === 0) {
                    this.player.center.x += 8;
                }
            }

            return;
        }

        if (this.needToSpawnEnemies) {
            this.spawnEnemies();
            this.needToSpawnEnemies = false;
        }

        for (var i = 0; i < self.bodies.length; i++) {
            self.bodies[i].update();
        }

        //Check to see if Link is colliding with any objects
        _.each(self.bodies, function (body) {
            if (!(body instanceof Player)) {
                if (doBodiesCollide(link, body)) {
                    //ITEMS
                    if (body instanceof Sword) {
                        link.hasSword = true;
                        self.removeBody(body);
                        $("#cave-text").text("");
                        self.removeBodyByType(OldMan)
                        Sound.fanfare.play();
                    } else if (body instanceof BlueCandle) {
                        if (link.rupees >= body.price) {
                            link.hasBlueCandle = true;
                            self.subtractRupeeCount = body.price;
                            self.removeBody(body);
                        }
                    } else if (body instanceof CaveRupee) {
                        if (!body.pickedUp) {
                            self.addRupeeCount = body.value;
                            body.pickup();
                        }
                    }

                    //ENEMIES
                    if (body instanceof RedOctorok) {
                        if (link.isSwingingSword()) {
                            body.kill();
                        } else {
                            if (!link.isInvincible) {
                                link.takeDamage(body)
                            }
                        }
                    }
                }
            }
        });

        var swordPower = this.getFirstBodyByType(SwordPower);

        if (swordPower) {
            _.each(self.bodies, function (body) {
                if (!(body instanceof Player) && !(body instanceof SwordPower)) {
                    if (doBodiesCollide(swordPower, body)) {
                        if (body instanceof RedOctorok) {
                            swordPower.remove();
                            body.kill();
                        }
                    }
                }
            });
        }

        var candleFire = this.getFirstBodyByType(CandleFire);

        if (candleFire) {
            _.each(self.bodies, function (body) {
                if (!(body instanceof Player) && !(body instanceof CandleFire)) {
                    if (doBodiesCollide(candleFire, body)) {
                        if (body instanceof RedOctorok) {
                            body.kill();
                        }
                    }
                }
            });
        }

        var bombExplosion = this.getFirstBodyByType(BombExplosion);

        if (bombExplosion) {
            _.each(self.bodies, function (body) {
                if (!(body instanceof BombExplosion)) {
                    if (doBodiesCollide(bombExplosion, body)) {
                        if (body instanceof CaveEntrance) {
                            body.show();
                        } else if (body instanceof Player) {
                            if (!link.isInvincible) {
                                link.takeDamage(bombExplosion)
                            }
                        } else if (body instanceof RedOctorok) {
                            body.kill();
                        }
                    }
                }
            });
        }


        /* DEBUG */

//            $("#link-x").text(Number(this.player.center.x).toFixed(2));
//            $("#link-y").text(Number(this.player.center.y).toFixed(2));
//
//            $("#link-x-square").text(this.player.tile.x);
//            $("#link-y-square").text(this.player.tile.y);
//
//            $("#map-x").text(this.map.x);
//            $("#map-y").text(this.map.y);

    }
}

var Player = function(game, gameSize) {
    this.id = "link-up-1";
    this.game = game;
    this.size = { x: 16, y: 16 };
    this.color = "#0088FF";
    this.center = { x: gameSize.x / 2, y: gameSize.y / 2 };
    this.tile = {x: 8, y: 5};
    this.moveRate = 1.3;

    // Create a keyboard object to track button presses.
    this.keyboarder = new Keyboarder();
};

var Keyboarder = function () {

    // Records up/down state of each key that has ever been pressed.
    var keyState = {};

    // When key goes down, record that it is down.
    window.addEventListener('keydown', function (e) {
        keyState[e.keyCode] = true;
    });

    // When key goes up, record that it is up.
    window.addEventListener('keyup', function (e) {
        keyState[e.keyCode] = false;
    });

    // Returns true if passed key is currently down.  `keyCode` is a
    // unique number that represents a particular key on the keyboard.
    this.isDown = function (keyCode) {
        return keyState[keyCode] === true;
    };

    // Handy constants that give keyCodes human-readable names.
    this.KEYS = { UP: 38, DOWN: 40, LEFT: 37, RIGHT: 39, SPACE: 32, ENTER: 13, C: 67 };
};


var doBodiesCollide = function (b1, b2) {
    var isColliding = !(
        b1 === b2 ||
            b1.center.x + b1.size.x / 2 < b2.center.x - b2.size.x / 2 ||
            b1.center.y + b1.size.y / 2 < b2.center.y - b2.size.y / 2 ||
            b1.center.x - b1.size.x / 2 > b2.center.x + b2.size.x / 2 ||
            b1.center.y - b1.size.y / 2 > b2.center.y + b2.size.y / 2
        );

    return isColliding;
};

var getRandomDirection = function () {
    var random = Math.floor(Math.random() * (4)) + 1;

    switch (random) {
        case 1:
            return "up";
            break;
        case 2:
            return "down";
            break;
        case 3:
            return "left";
            break;
        case 4:
            return "right";
            break;
        default:
            return "up";
    }
};


window.addEventListener('load', function () {
    new Game();

    var widthScale = Number(window.innerWidth / 256).toFixed(2);
    var heightScale = Number(window.innerHeight / 346).toFixed(2);

    if (widthScale <= heightScale) {
        $("meta[name=viewport]").attr("content", "initial-scale=" + widthScale + ", user-scalable=no");
//            $('body').css('zoom', widthScale * 100 + "%");
    } else {
        $("meta[name=viewport]").attr("content", "initial-scale=" + heightScale + ", user-scalable=no");
//            $('body').css('zoom', heightScale * 100 + "%");
    }
    
});